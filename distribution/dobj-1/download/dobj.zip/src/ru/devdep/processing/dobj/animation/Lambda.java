package ru.devdep.processing.dobj.animation;

public interface Lambda<T> {
	public void run( T o );
}